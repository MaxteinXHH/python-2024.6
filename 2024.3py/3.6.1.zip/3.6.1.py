a=input("输入一个整数")
a=int(a)
if a%4==0 and a%7!=0:
    print("是")
else:
    print("否")

