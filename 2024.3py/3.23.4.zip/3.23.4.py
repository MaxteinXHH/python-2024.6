a=eval(input("输入一位同学的成绩"))
if a==-1:
    i= 1
else:
    i=0
b=0
while a!= -1 :
    b+=a
    i+=1
    a=eval(input("输入一位同学的成绩"))
print(f"平均分为{b/i}")




a=input("")   #保留窗口
        
