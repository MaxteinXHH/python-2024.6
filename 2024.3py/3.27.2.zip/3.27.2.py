import random
a=random.randint(7,15)    # 随机元素个数
lis=[]
for i in range (a):
    b=random.randint(10,99)
    lis = lis +[b]
lis.sort()
print(lis)












































a=input(" ")  #保留窗口









