lis=input("输入一串大写英文字母")
a=lis[3]
a=a.lower()
print(lis[0:3],a,lis[4:])

