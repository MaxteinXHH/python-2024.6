a=0
b=0
for i in range(50,101):
    if i%2==0:
        a+=i
    else:
        b+=i
print(f"奇数和为{b}，偶数和为{a}")


a=input("") #保留窗口
        
