lis = ['zero','one','two','three','four','five','six','seven','eight','nine']
a=input("Please input a number !")
b=" "
for i in a :
    if i =='.' :
        b = b + " point " 
    else :
        i=int(i)
        b = b + lis[i] +" "
print(b)        




















o=input(" ")







