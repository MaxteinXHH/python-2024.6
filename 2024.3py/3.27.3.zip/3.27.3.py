import random
lis1=[]
lis2=[]
for i in range (5) :
    a = random.randint(100,200)
    lis1 = lis1 + [a]
    b = random.randint(200,300)
    lis2 = lis2 + [b]
lis1 = lis1 + lis2
print(lis1,"\n最大值为",max(lis1),"\n最小值为",min(lis1))


































a=input(" ")   #保留窗口

















