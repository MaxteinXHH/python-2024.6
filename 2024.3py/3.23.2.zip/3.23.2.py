k=0
for i in range(100,301):
    if i%3==0:
        print(i,end=" ")
        k+=1
        if k==5:
            print(" ")
            k=0



            
a=input("")#保留窗口
        
