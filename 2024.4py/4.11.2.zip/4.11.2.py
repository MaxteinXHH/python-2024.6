def power(m,n=2):
    c=m**n
    return c
a,b=eval(input("输入m和n（请用英文逗号分开）"))
f=power(a,b)
print(f)
























hi=input(" ")
