list1=[['王小伟',90,86,95],['张凌云',89,78,75],['袁潇',85,89,95]]
dict1={}
for i in list1 :
    dict1[i[0]]=sum(i[1:])
for key,vaule in dict1.items() :
    print(key,vaule)








a=input("  ")
