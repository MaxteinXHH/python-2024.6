s=input("(先下载myModuleXhh.py和此文件，并移出压缩包放入同一文件夹或桌面内，不能在压缩包内操作)\n\n输入四位数整数以判断")
from myModuleXhh import irn
from myModuleXhh import isn


jj=irn(s)
jk=isn(s)
print("\n\n",jj,jk)





xhh=input("")
