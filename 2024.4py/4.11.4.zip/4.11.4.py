def sort2Num(m,n):
    if a>b:
        lv=b,a
    else:
        lv=a,b
    return lv
a,b=eval(input("请输入两个数字(用英文逗号，分离)，以排序"))
f=sort2Num(a,b)
print(f)









hi=input( "\n\n\n\n\n\n\n\n\n\n\n\n made in maxtein")
