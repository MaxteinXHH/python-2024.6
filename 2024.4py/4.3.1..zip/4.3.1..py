score={"zhang san":85, "li sa":78,"wangwu":90}
sco=list(score.values())
su=0
for i in sco :
    su+=i
av=su/3
print(f"最高分为：{max(sco)},最低分为：{min(sco)},平均分为：{round(av,3)}.")



































q=input("")
