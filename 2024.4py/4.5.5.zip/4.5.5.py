list1=[12,15,35,68,'a','c',12,68]
a=set(list1)
print(a)


















h=input("  ")
