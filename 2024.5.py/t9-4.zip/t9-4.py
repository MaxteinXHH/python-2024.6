list1=[['安小捷',90,86,95],['曹翔',89,78,75],['党红红',85,89,95],['云峰',65,76,80],['张潇',72,75,76],['藏晴',58,69,45]]
b=0
for i in list1:
    b+=1
    a4=int(i[1])+int(i[2])+int(i[3])
    list1[b-1].append(a4)
file=open("grade.txt","w")
for i in list1:
    file.write(str(i))
file.close()
print("操作成功")




k=input("    ")
