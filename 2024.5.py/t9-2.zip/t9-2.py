import random
files=open("date.txt","w")
for i in range(100):
    a=random.randint(1,10000)
    b=str(a)+"\n"
    files.write(b)
files.close()
print("操作成功")



xhh=input("   ")

