def is_palinnum(a):
    if a==a[::-1]:
        return True
    else:
        return False
files=open("palin.txt","a")
t=0
for i in range(500,5000):
    i=str(i)
    v=is_palinnum(i)
    if v:
        t+=1
        files.write(i)
        if t%5==0:
            files.write('\n')
        else:
            files.write('  ')
files.close()
