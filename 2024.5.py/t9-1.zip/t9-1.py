file=open("dataFile.dat",'r')
str1=0
for i in file:
    stre=int(file.readline())
    str1=str1+stre
print(str1)


xhh=input(" ")
